﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("hello world");
            for (int i =1; i<=5; i++)
            {
                Console.WriteLine("valor de i: {0}", i);
            }
            var numeros = new int[] { 1, 2, 3 };
            foreach (int elem in numeros) { 
                Console.Write(elem + " ");
                Console.Write($"usando o $: {elem}\n");
            }
            var a = 10;
            Console.WriteLine(a);
            a = Int32.Parse("Dez");
            Console.WriteLine(a);

            Televisao tv = new Televisao("marca", 10, "grande");
            tv.Ligar();

        }
    }
}
