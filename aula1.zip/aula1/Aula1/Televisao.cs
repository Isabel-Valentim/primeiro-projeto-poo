﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Aula1
{
    internal class Televisao
    {

        public String marca;
        public int tamanho;
        public String tipo;

        public Televisao(String emarca, int etamanho, String etipo)
        {
            marca = emarca;
            tamanho = etamanho;
            tipo = etipo;
        }
        public void Ligar() {
            Console.WriteLine("A TV foi ligada");
        }
        public void Desligar()
        {
            Console.WriteLine("A TV foi desligada");
        }
        public void MudarCanal()
        {
            Console.WriteLine("O canal foi alterado");
        }
    } 
}
        

